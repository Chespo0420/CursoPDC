
import servicios.Producto_Servicio;

/**
 *
 * @author Kyouma
 */
public class NewMain {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        Producto_Servicio producto_Servicio = new Producto_Servicio();

        //producto_Servicio.Nombre_Producto();
        //producto_Servicio.Nom_precio();
        //producto_Servicio.mostrarPrecio();
        //producto_Servicio.mostrarPortatil();      
        producto_Servicio.crearProducto();
        producto_Servicio.Nom_precioo();

    }

}
