package com.gui;

import javax.swing.*;

public class MonsterZoneButton extends JButton{
    public MonsterZoneButton(){

    }


}
