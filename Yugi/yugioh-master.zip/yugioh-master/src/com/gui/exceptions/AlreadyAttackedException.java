package com.gui.exceptions;

public class AlreadyAttackedException extends RuntimeException {
    
    public AlreadyAttackedException(String message){
        super(message);
    }

}
