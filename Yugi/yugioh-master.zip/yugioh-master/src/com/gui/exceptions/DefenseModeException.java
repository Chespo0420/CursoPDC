package com.gui.exceptions;

public class DefenseModeException extends RuntimeException {

    public DefenseModeException(String message){
        super(message);
    }

}