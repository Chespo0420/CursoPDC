package com.gui.exceptions;

public class MaxHandSizeException extends RuntimeException {

    public MaxHandSizeException(String message){
        super(message);
    }

}
