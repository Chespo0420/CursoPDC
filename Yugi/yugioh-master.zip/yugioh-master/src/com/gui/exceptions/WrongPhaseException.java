package com.gui.exceptions;

public class WrongPhaseException extends RuntimeException {

    public WrongPhaseException(String message){
        super(message);
    }

}
