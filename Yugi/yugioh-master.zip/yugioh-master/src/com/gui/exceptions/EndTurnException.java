package com.gui.exceptions;

public class EndTurnException extends RuntimeException {

    public EndTurnException(String message){
        super(message);
    }

}
