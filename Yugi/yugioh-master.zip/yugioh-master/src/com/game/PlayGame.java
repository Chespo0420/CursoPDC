package com.game;

public class PlayGame {

    public static void main(String args[]){
        Game newGame = new Game();
        newGame.startNewGame();
    }

}
